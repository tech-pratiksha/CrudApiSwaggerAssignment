﻿using CrudApi.Data;
using CrudApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace CrudApi.Controllers
{
    [Route("api/[Controller]")]
    public class StudentController : Controller
    {
        private Context con;

        public StudentController(Context context)
        {
            con = context;
        }


        // Get Method ....List of all Students
        [HttpGet]
        public List<Student> Get()
        {
            return con.students.ToList();
        }

        [HttpGet("{Id}")]

        public Student GetStudent(int Id)
        {
            var student = con.students.Where(a => a.Id == Id).SingleOrDefault();
            return student;
        }

        [HttpPost]
        public ActionResult PostStudent([FromBody] Student student)
        {
            if (!ModelState.IsValid)
                return BadRequest("Not a valid Model");
            con.students.Add(student);
            con.SaveChanges();
            return Ok();
        }

        // PUT api/<StudentController>/5
        [HttpPut("{Id}")]
        public void Put(int id, [FromBody] Student student)
        {
            // student.StudentId = id;
            con.students.Update(student);
            con.SaveChanges();
        }



        // DELETE api/<StudentController>/5
        [HttpDelete("{Id}")]
        public void Delete(int id)
        {
            var item = con.students.FirstOrDefault(x => x.Id == id);
            if (item != null)
            {
                con.students.Remove(item);
                con.SaveChanges();
            }
        }
    }
}