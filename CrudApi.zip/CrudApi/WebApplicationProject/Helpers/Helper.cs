﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationProject.Helper
{
    public class StudentAPI
    {
        var client = new HttpClient();
        Client.BaseAddress = new UriKind("http://localhost:53196/");
        return client;
internal HttpClient Initial()
        {
            throw new NotImplementedException();
        }
    }
}
